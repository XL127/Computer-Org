1. The project directory is Phase3
2. in order to test the different cache configuration, it is needed to replace the Dinero.java file in the project from the cache configuration.
3. The cache configuration contains different cache configurations. The name of each file indicate the configuration