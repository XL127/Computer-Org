package org.edumips64.ui.swing;

public class OutOfRangeException extends Exception {}