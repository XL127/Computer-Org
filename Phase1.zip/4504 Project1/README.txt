For the first modification:
Probably need to add External Jars javahelp-2.0.05.jar gwt-elemental.jar gwt-user.jar jsinterop-annotations-1.0.0.jar
then Run the original source code and click Configure - Settings - Main settings - Enable forwarding

For the second modification:
Probably need to add External Jars javahelp-2.0.05.jar gwt-elemental.jar gwt-user.jar jsinterop-annotations-1.0.0.jar
then Run the modified source code